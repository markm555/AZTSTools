import re
import requests
import json
import os
import sys
from dotenv import load_dotenv
from azure.identity import ClientSecretCredential
import csv
import uuid

# Define the colors for the output
green='\033[32m'
cyan='\033[36m'
yellow='\033[33m'
red='\033[31m'
reset='\033[0m'
pipe='\033[36m|\033[0m'
envFile = 'purview-horizon.env'

# Function to clear the screen
def clearScreen():
    os.system('cls' if os.name == 'nt' else 'clear')

# Function to refresh the credentials and get the access token
def refreshCredentials():
    # logging.basicConfig(level=logging.DEBUG)
    credential = ClientSecretCredential(
        tenant_id=os.environ.get("AZURE_TENANT_ID"),
        client_id=os.environ.get("AZURE_CLIENT_ID"),
        client_secret=os.environ.get("AZURE_CLIENT_SECRET")
    )
    # Get the access token using DefaultAzureCredential
    accessToken = credential.get_token(f"https://purview.azure.net/.default").token
    # Set up the headers with the access token
    headers = { "Authorization": f"Bearer {accessToken}", "Content-Type": "application/json" }
    # print(f"Access Token: {accessToken}")
    return credential,accessToken,headers

def getGovernanceDomainByName(endpoint, headers, DomainName=None):
    if DomainName:
        domainName = DomainName
    else:
        domainName = input("Enter the Governance Domain Name: ")
    search_url = f"{endpoint}/datagovernance/catalog/businessdomains?api-version=2025-09-15-preview"

    continuation_token = None
    while True:
        if continuation_token:
            search_url += f"&continuationToken={continuation_token}"

        response = requests.get(search_url, headers=headers)
        if response.status_code != 200:
            break

        data = response.json()
        # Uncomment the next line to see the full JSON response for debugging
        
        for domain in data.get('value', []):
            if domainName in [domain['name']]:
                # domainId = domain['id']
                print(f"Found Governance Domain: Name: {domain['name']} - GUID: {domain['id']} - Status: {domain['status']}")
                return domain
            
        continuation_token = data.get("continuationToken")

        if not continuation_token:
            break
            
    return None

def getGlossaryTerms(endpoint, headers):
    term_url = f"{endpoint}/datagovernance/catalog/terms?api-version=2025-09-15-preview"

    glossaryTermName = input("Enter the Glossary Term Name to search for (or press Enter to list all): ")

    continuation_token = None
    while True:
        if continuation_token:
            term_url += f"&continuationToken={continuation_token}"

        response = requests.get(term_url, headers=headers)
        if response.status_code != 200:
            break

        data = response.json()
        # Uncomment the next line to see the full JSON response for debugging
        
        print(f"Glossary Terms Found: {len(data.get('value', []))}\n\n")
        for term in data.get('value', []):
            if glossaryTermName and glossaryTermName not in [term['name']]:
                continue
            else:
                print(f"Name: {term['name']} - GUID: {term['id']} - Status: {term['status']}")
                print(json.dumps(term, indent=3))

        continuation_token = data.get("continuationToken")

        if not continuation_token:
            break

def updateGlossaryTerm(endpoint, headers):
    governanceDomain = getGovernanceDomainByName(endpoint, headers)
    statusToUpdate = input("Enter the Status to update (e.g., Draft, Published, Expired): ")
    term_url = f"{endpoint}/datagovernance/catalog/terms?api-version=2025-09-15-preview&domainId={governanceDomain['id']}"
    continuation_token = None
    while True:
        if continuation_token:
            term_url += f"&continuationToken={continuation_token}"

        response = requests.get(term_url, headers=headers)
        if response.status_code != 200:
            break

        data = response.json()
        
        print(f"Glossary Terms Found: {len(data.get('value', []))}\n\n")
        for term in data.get('value', []):
            if term['status'] == statusToUpdate:
                print(f"Skipping --> Name: {term['name']} - GUID: {term['id']} - Status: {term['status']} (already {statusToUpdate})")
                continue
            print(f"Updating --> Name: {term['name']} - GUID: {term['id']} - Status: {term['status']} to {statusToUpdate}")
            term['status'] = statusToUpdate
            update_term_url = f"{endpoint}/datagovernance/catalog/terms/{term['id']}?api-version=2025-09-15-preview"
            update_response = requests.put(update_term_url, headers=headers, json=term)

        continuation_token = data.get("continuationToken")

        if not continuation_token:
            break

def deleteALLGlossaryTerms(endpoint, headers):
    governanceDomain = getGovernanceDomainByName(endpoint, headers)
    prompt = input("Are you sure you want to DELETE ALL glossary terms in this Governance Domain (Y|N)?:")
    if prompt.lower() != 'y':
        print("Aborting deletion of glossary terms.")
        return
    force = input("Do you want to force deletion for all the assets (Y|N)?:")
    term_url = f"{endpoint}/datagovernance/catalog/terms?api-version=2025-09-15-preview&domainId={governanceDomain['id']}"
    continuation_token = None

    while True:
        if continuation_token:
            term_url += f"&continuationToken={continuation_token}"

        response = requests.get(term_url, headers=headers)
        if response.status_code != 200:
            break

        data = response.json()
        
        print(f"Glossary Terms Found: {len(data.get('value', []))}\n\n")
        for term in data.get('value', []):
            if force.lower() == 'y' and term['status'] != 'Draft':          
                update_term_url = f"{endpoint}/datagovernance/catalog/terms/{term['id']}?api-version=2025-09-15-preview"
                print(f"Updating --> Name: {term['name']} - GUID: {term['id']} - Status: {term['status']} to Draft for deletion")
                term['status'] = 'Draft'
                update_response = requests.put(update_term_url, headers=headers, json=term)
            if term['status'] == 'Published':
                print(f"Skipping deletion of Published term: Name: {term['name']} - GUID: {term['id']} - Status: {term['status']}")
                continue
            print(f"Deleting --> Name: {term['name']} - GUID: {term['id']} - Status: {term['status']}")
            delete_term_url = f"{endpoint}/datagovernance/catalog/terms/{term['id']}?api-version=2025-09-15-preview"
            delete_response = requests.delete(delete_term_url, headers=headers)

        continuation_token = data.get("continuationToken")

        if not continuation_token:
            break

def addGlossaryTerm(endpoint, headers):
    governanceDomainName = input("Enter the Governance Domain Name: ")
    governanceDomainDetails = getGovernanceDomainByName(endpoint, headers, governanceDomainName)

    term_url = f"{endpoint}/datagovernance/catalog/terms?api-version=2025-09-15-preview"

    body = {
            "status": "DRAFT",
            "name": "Demo Term 1",
            "description": "This is a demo glossary term created via API.",
            "contacts": {
                "owner": [
                {
                    "id": "70ba3017-ec4e-431b-bd57-74528155778d",
                    "description": "System Administrator"
                }
                ]
            },
            "domain": f"{governanceDomainDetails['id']}",
            "parentId": "",
            "acronyms": [
                "GTSA1",
                "SampleTerm1"
            ],
            "resources": [
                {
                "name": "myDataProduct",
                "url": "https://www.microsoft.com"
                }
            ],
            "isLeaf": True,
        }

    try:
        response = requests.post(term_url, headers=headers, json=body)
        print(json.dumps(response.json(), indent=3))
    except Exception as e:
        print(f"❌ Failed to create glossary term. Error: {str(e)}")
        return

def addGlossaryTermBulk(credential,endpoint, headers):
    csv_path = input("Enter the path to the CSV file (default: glossary_term_bulk.csv): ")
    if not csv_path:
        csv_path = "glossary_term_bulk.csv"
    term_url = f"{endpoint}/datagovernance/catalog/terms?api-version=2025-09-15-preview"

    with open(csv_path, newline="", encoding="utf-8-sig") as f:
            reader = csv.DictReader(f)
            if not reader.fieldnames:
                raise ValueError("CSV appears to have no header row.")

            row_num = 1  # header = row 1
            for row in reader:
                row_num += 1               
                governanceDomainDetails = getGovernanceDomainByName(endpoint, headers, row.get("governanceDomainName"))
                acronyms = row.get("acronyms").split(";")
                print(f"Adding term: {row.get('name')}")
                
                # ownerId = "70ba3017-ec4e-431b-bd57-74528155778d"
                ownerId = getEntraUserIdByUPN(credential, row.get("owner"))['id']
                expertId = getEntraUserIdByUPN(credential, row.get("expert"))['id'] 
                if not ownerId:
                    print(f"❌ Skipping term {row.get('name')} due to missing owner ID.")
                    continue

                body = {
                        "status": f"{row.get('status')}",
                        "name": f"{row.get('name')}",
                        "description": f"{row.get('description')}",
                        "contacts": {
                            "owner": [
                                {
                                    "id": f"{ownerId}",
                                    "description": "Glossary Term Owner"
                                },
                            ],
                            "expert": [
                                {
                                    "id": f"{expertId}",
                                    "description": "Expert Data Steward"
                                },
                            ]
                        },
                        "domain": f"{governanceDomainDetails['id']}",
                        "parentId": "",
                        "acronyms": acronyms,
                        "resources": [
                            {
                            "name": f"{row.get('name')}",
                            "url": f"{row.get('resources')}"
                            }
                        ],
                        "isLeaf": row.get("isLeaf"),
                    }

                try:
                    response = requests.post(term_url, headers=headers, json=body)
                    # print(json.dumps(response.json(), indent=3))
                except Exception as e:
                    print(f"❌ Failed to create glossary term. Error: {str(e)}")
                    return

def getEntraUserIdByUPN(credential, userPrincipalName: str):
    GRAPH_SCOPE = "https://graph.microsoft.com/.default"
    GRAPH_BASE  = "https://graph.microsoft.com/v1.0"
    accessToken = credential.get_token(GRAPH_SCOPE).token
    if not accessToken:
        print("❌ Failed to obtain access token for Microsoft Graph API.")
        return None
    if not userPrincipalName:
        userPrincipalName = input("Enter the User Principal Name (UPN): ")

    headers = { "Authorization": f"Bearer {accessToken}" }
    graph_url = f"{GRAPH_BASE}/users/{userPrincipalName}"
    response = requests.get(graph_url, headers=headers)
    if response.status_code == 200:
        data = response.json()
        # print(f"✅ User ID for {userPrincipalName} is {data['id']}")
        return data
    else:
        print(f"❌ Failed to retrieve user ID for {userPrincipalName}. Status {response.status_code}")
        print(response.text)
        return None
    
def menuContents(purviewEndpointUrl, headers, credential):
    return [
        (f"List Glossary Terms", getGlossaryTerms, (purviewEndpointUrl, headers)),
        (f"Add Glossary Term", addGlossaryTerm, (purviewEndpointUrl, headers)),
        (f"Add Glossary Terms in Bulk from CSV", addGlossaryTermBulk, (credential, purviewEndpointUrl, headers)),
        (f"Update ALL Glossary Terms in a Governance Domain", updateGlossaryTerm, (purviewEndpointUrl, headers)),
        (f"Delete ALL Glossary Terms in a Governance Domain", deleteALLGlossaryTerms, (purviewEndpointUrl, headers)),
        (f"Refresh Credentials", refreshCredentials, ()),
        (f"{red}Exit{reset}\n", None, (None, None))
    ]

# Function to display the menu
def showMenu(options):
    # clearScreen()
    print(f"\n\n{green}{'Purview Inventory Tool':^60}{reset}\n")
    print(f"Option Menu:\n")
    for i, (description, _, _) in enumerate(options, 1):
        print(f"\t{i}. {description}")

# Function to get the user's choice from available menu options
def getChoice(num_options):
    while True:
        try:
            choice = int(input("Choose an option: "))
            if 1 <= choice <= num_options:
                return choice
            else:
                print(f"Please enter a number between 1 and {num_options}.")
        except ValueError:
            print("Invalid input. Please enter a number.")

# Main function
def main():
    clearScreen()
    # Read environment variables and assign to local variables or exit if the file is not found
    if os.path.exists(envFile):
        load_dotenv(envFile)       
        tenantId=os.getenv("AZURE_TENANT_ID")
        clientId=os.getenv("AZURE_CLIENT_ID")
        clientSecret=os.getenv("AZURE_CLIENT_SECRET")
        subscriptionId=os.getenv("AZURE_SUBSCRIPTION_ID")
        purviewAccountName=os.getenv("PURVIEW_ACCOUNT_NAME")
        if tenantId == None or clientId == None or clientSecret == None or subscriptionId == None:
            tenantId=""
            clientId=""
            clientSecret=""
            subscriptionId=""
        else:
            print(f"{green}Environment variables loaded successfully from {yellow}{envFile}{green} file.{reset}")

        # Define the API endpoint for listing data sources
        purviewEndpointUrl = f"https://{purviewAccountName}.purview.azure.com"
    else:
        clearScreen()
        print(f"\n\n{red}Failed to load environment variables from {yellow}{envFile}{red} file. Please check the file and try again.{reset}\n\n")
        sys.exit(0)

    # Get the access token using DefaultAzureCredential
    credential,accessToken,headers = refreshCredentials()

    # Define the menu options
    menuOptions = menuContents(purviewEndpointUrl, headers, credential)

    # Display the menu and get the user's choice
    while True:
        showMenu(menuOptions)
        choice = getChoice(len(menuOptions))
        if choice == len(menuOptions):
            print("Exiting...")
            break
        else:
            _, func, args = menuOptions[choice - 1]
            if _ == "Refresh Credentials":
                # Refresh the credentials, get the access token, and update menuOptions
                credential,accessToken,headers = func(*args)
                menuOptions = menuContents(purviewEndpointUrl, headers, credential)
                print(f"{green}Credentials refreshed successfully.{reset}")
                input("Press Enter to continue...")
            else:
                if func:
                    func(*args)
                    input("Press Enter to continue...")

# Call the main function
if __name__ == "__main__":
    main()