***

# Microsoft Purview Glossary API Utility

A menu‑driven Python CLI for managing **Microsoft Purview Data Governance glossary terms** using the **Purview REST APIs (preview)** and **Microsoft Entra ID (Azure AD)**.

This tool supports interactive and bulk operations for glossary lifecycle management across governance domains.

***

## 🚀 Features

*   Authenticate using **Service Principal (Client Credentials)**
*   List glossary terms (optionally filter by name)
*   Create individual glossary terms
*   Bulk‑create glossary terms from CSV
*   Update glossary term status across an entire governance domain
*   Delete all glossary terms in a governance domain (with safety checks)
*   Resolve glossary owners and experts via **Microsoft Graph (UPN → Object ID)**
*   Interactive command‑line menu

***

## 🧭 Use Cases

*   Enterprise glossary onboarding
*   Bulk glossary seeding during governance rollout
*   Governance domain lifecycle management
*   Test / non‑prod glossary cleanup
*   Controlled glossary redesigns

***

## 📦 Prerequisites

### Azure & Microsoft Purview

*   Microsoft Purview account with **Data Governance** enabled
*   Governance Domains already created
*   Azure AD (Entra ID) **Service Principal** with:
    *   Purview Data Governance permissions (**Data Steward** on each governance domain where the terms will be created).
    *   Microsoft Graph `User.Read.All` **Application** permission

### Python

*   Python **3.9+**

Install dependencies:

```bash
pip install requests python-dotenv azure-identity
```

***

## 🔐 Authentication Model

| API                 | Purpose                          |
| ------------------- | -------------------------------- |
| Purview REST API    | Glossary & governance operations |
| Microsoft Graph API | Resolve Owner / Expert UPNs      |

Tokens are acquired using `ClientSecretCredential`.

***

## ⚙️ Environment Configuration

The script reads configuration from:

```text
purview.env
```

### Required Variables inside purview.env

```env
AZURE_TENANT_ID=<tenant-id>
AZURE_CLIENT_ID=<client-id>
AZURE_CLIENT_SECRET=<client-secret>
AZURE_SUBSCRIPTION_ID=<subscription-id>
PURVIEW_ACCOUNT_NAME=<purview-account-name>
```

⚠️ **The script exits if this file is missing or incomplete.**

***

## ▶️ Running the Tool

```bash
python purview-API-glossary.py
```

***

## 🧩 Menu Options

```text
1. List Glossary Terms
2. Add Glossary Term
3. Add Glossary Terms in Bulk from CSV
4. Update ALL Glossary Terms in a Governance Domain
5. Delete ALL Glossary Terms in a Governance Domain
6. Refresh Credentials
7. Exit
```

***

## 📘 Functionality Overview

### 1️⃣ List Glossary Terms

*   Lists all glossary terms
*   Optional name filter
*   Outputs full JSON payload for inspection

***

### 2️⃣ Add a Single Glossary Term

Creates a sample glossary term in a selected governance domain.

Included fields:

*   Name
*   Description
*   Owner
*   Acronyms
*   Resources

> Intended as a **starter template** for customization.

***

### 3️⃣ Bulk Add Glossary Terms (CSV)

Creates multiple glossary terms from a CSV file.

#### Default File Name

```text
glossary_term_bulk.csv
```

#### Required CSV Columns

| Column               | Description                |
| -------------------- | -------------------------- |
| name                 | Glossary term name         |
| description          | Term description           |
| status               | Draft / Published          |
| governanceDomainName | Target governance domain   |
| acronyms             | Semicolon‑separated values |
| owner                | Owner UPN                  |
| expert               | Expert UPN                 |
| resources            | URL                        |
| isLeaf               | true / false               |

✅ Owners and experts are resolved automatically via Microsoft Graph.

***

### 4️⃣ Update All Glossary Terms in a Governance Domain

*   Updates the **status** of all glossary terms in a domain
*   Skips terms already in the target status
*   Useful for bulk publishing or retirement workflows

***

### 5️⃣ Delete All Glossary Terms in a Governance Domain

⚠️ **Destructive Operation**

Safety features:

*   Explicit confirmation prompt
*   Optional forced downgrade to `Draft`
*   Published terms are protected unless forced

Recommended for:

*   Test environments
*   Non‑production cleanup
*   Controlled glossary resets

***

### 6️⃣ Refresh Credentials

*   Re‑authenticates to Azure
*   Refreshes Purview and Graph tokens
*   No restart required

***

## 🔍 API Version Used

```text
api-version=2025-09-15-preview
```

> This tool uses **preview APIs**. Behavior may change as Purview evolves.

***

## 🔒 Security Considerations

*   Do **not** commit `.env` files to source control
*   Use least‑privilege service principals
*   Validate governance domain selection before bulk operations
*   Avoid running delete operations in production

***

## ⚠️ Known Limitations

*   No retry or backoff logic
*   Interactive (not designed for unattended automation)
*   No dry‑run mode
*   Lightweight error handling by design

***

## 🛠️ Suggested Enhancements

*   Dry‑run mode for bulk operations
*   Idempotency checks
*   Structured logging
*   CI/CD‑friendly non‑interactive mode
*   Glossary hierarchy (parent/child) support

***

## 📄 License

This project is provided **as‑is** for internal or educational use.  
Review and adapt before using in production environments.

***

## 👤 Audience

Designed for:

*   Data Governance teams
*   Platform & Cloud Architects
*   Microsoft Purview administrators
*   Regulated enterprise environments
